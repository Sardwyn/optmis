<?php
/**
 * Plugin Name: Supplier Scraper
 * Description: Scrapes product data from supplier websites and imports into WooCommerce manually.
 * Version:     0.9.6
 * Author:      Bradley Templeton
 */

if (!defined('ABSPATH')) exit;

if (!defined('PSS_PLUGIN_DIR')) define('PSS_PLUGIN_DIR', plugin_dir_path(__FILE__));
if (!defined('PSS_PLUGIN_URL')) define('PSS_PLUGIN_URL', plugin_dir_url(__FILE__));

function pss_render_admin_page() {
    echo '<div class="wrap">
        <h1>Supplier Product Scraper</h1>
        <div id="pss-ui-root"></div>
        <pre id="pss-log-console" style="background:#111;color:#0f0;padding:10px;max-height:300px;overflow:auto;font-family:monospace;margin-top:15px;"></pre>
        <div id="pss-scraped-output"></div>
        <div id="pss-failed-imports" style="display:none;margin-top:20px;"></div>
        <div id="pss-admin-preview-wrapper" style="position:fixed;top:80px;right:0;width:900px;height:800px;z-index:9999;background:#fff;border-left:2px solid #ccc;box-shadow:-4px 0 20px rgba(0,0,0,0.15);display:none;">
          <div style="background:#f1f1f1;padding:8px;border-bottom:1px solid #ddd;text-align:right;">
            <button id="pss-preview-close" class="button">Close Preview</button>
          </div>
          <iframe id="pss-admin-preview-frame" style="width:100%;height:calc(100% - 40px);border:0;"></iframe>
        </div>
    </div>';
}

add_action('admin_menu', function () {
    add_menu_page('Supplier Tools', 'Supplier Tools', 'manage_woocommerce', 'product-scraper', 'pss_render_admin_page');
    add_submenu_page('product-scraper', 'Scraper', 'Scraper', 'manage_woocommerce', 'product-scraper', 'pss_render_admin_page');
});

function pss_generate_ai_description($product, $api_key) {
    $specs = is_array($product['specs'] ?? null)
        ? implode(", ", $product['specs'])
        : ($product['specs'] ?? '');

    $category = $product['category'] ?? '';
    $title = $product['title'] ?? '';
    $variants = '';

    if (!empty($product['variants']) && is_array($product['variants'])) {
        $labels = array_column($product['variants'], 'label');
        $variants = 'Available in: ' . implode(', ', $labels) . '.';
    }

    $prompt = "Write a compelling WooCommerce product description using the following:\n\n" .
              "Title: $title\n" .
              ($category ? "Category: $category\n" : '') .
              ($variants ? "$variants\n" : '') .
              "Specs: $specs\n\n" .
              "Format it as a 2-3 sentence product overview.";

    if (!$api_key) {
        error_log('❌ No OpenAI API key found.');
        return '';
    }

    $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        ],
        'body' => json_encode([
            'model' => 'gpt-4',
            'messages' => [
                ['role' => 'system', 'content' => 'You are a helpful assistant that writes high-quality WooCommerce product descriptions.'],
                ['role' => 'user', 'content' => $prompt],
            ],
            'max_tokens' => 150,
            'temperature' => 0.7,
        ])
    ]);

    if (is_wp_error($response)) {
        error_log('❌ OpenAI API Error: ' . $response->get_error_message());
        return '';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (!isset($data['choices'][0]['message']['content'])) {
        error_log('⚠️ Unexpected OpenAI Response: ' . $body);
        return '';
    }

    $generated_description = $data['choices'][0]['message']['content'];
    error_log('✅ AI Generated Description: ' . $generated_description);

    return $generated_description;
}

add_action('wp_ajax_pss_import_products', function () {
    try {
        check_ajax_referer('pss_scraper_nonce', 'security');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $raw = stripslashes($_POST['products'] ?? '[]');
        $products = json_decode($raw, true);
        $category_map = get_option('pss_category_map', []);
        $openai_key = get_option('pss_openai_api_key');
        $success = [];
        $failed = [];

        if (!is_array($products)) {
            wp_send_json_error(['message' => 'Invalid product payload']);
        }

        $ck = get_option('pss_wc_consumer_key');
        $cs = get_option('pss_wc_consumer_secret');

        if (empty($ck) || empty($cs)) {
        wp_send_json_error(['message' => 'Missing WooCommerce API credentials.']);
        }

        $auth_header = 'Basic ' . base64_encode("{$ck}:{$cs}");

        foreach ($products as $product) {
            if (!isset($product['type'])) {
                $hasVariants = isset($product['variants']) && is_array($product['variants']) && count($product['variants']) > 0;
                $product['type'] = $hasVariants ? 'variable' : 'simple';
            }
            

            $isGrouped = $product['type'] === 'variable' && !empty($product['variants']);

            if (empty($product['sku']) || empty($product['title'])) {
                error_log("❌ Skipping product: Missing SKU or title. " . print_r($product, true));
                continue;
            }

            if ($product['type'] === 'simple' && empty($product['price'])) {
                $product['price'] = '0.00';
            }

            if (empty($product['description']) && !empty($openai_key)) {
                $description = pss_generate_ai_description($product, $openai_key);
                if ($description) {
                    $product['description'] = $description;
                    error_log("🤖 AI Description Injected for SKU {$product['sku']}: " . substr($description, 0, 100));
                }
            }

            $slug = trim($product['category'] ?? '');
            if ($slug !== '' && isset($category_map[$slug])) {
            $product['categories'] = [['id' => (int) $category_map[$slug]]];
            } else {
            error_log("⚠️ Category mapping not found for slug: '{$slug}'");
            }


            $product['status'] = 'draft';

            if (get_option('pss_debug_mode') === 'yes') {
                error_log('[PSS DEBUG] Final product payload: ' . print_r($product, true));
            }

            if ($isGrouped) {
                $parent = $product;
                unset($parent['variants']);

                $res = wp_remote_post(get_rest_url(null, 'wc/v3/products'), [
                    'method'  => 'POST',
                    'headers' => [
                        'Authorization' => $auth_header,
                        'Content-Type'  => 'application/json',
                    ],
                    'body'    => json_encode($parent),
                    'timeout' => 20,
                ]);

                $body = wp_remote_retrieve_body($res);
                $code = wp_remote_retrieve_response_code($res);
                $parent_id = json_decode($body, true)['id'] ?? 0;

                if ($parent_id) {
                    foreach ($product['variants'] as $variant) {
                        $variant['status'] = 'draft';
                        $variant['regular_price'] = $variant['price'] ?? '0.00';
                        $variant['sku'] = $variant['sku'] ?? '';
                        $variant['attributes'] = [['name' => 'Option', 'option' => $variant['label'] ?? '']];
                        unset($variant['label']);

                        // Check if product with same SKU already exists
$res_check = wp_remote_get(get_rest_url(null, 'wc/v3/products?sku=' . urlencode($product['sku'])), [
    'headers' => [
        'Authorization' => $auth_header,
        'Content-Type'  => 'application/json',
    ],
]);

$existing = json_decode(wp_remote_retrieve_body($res_check), true);
$existing_id = is_array($existing) && !empty($existing[0]['id']) ? intval($existing[0]['id']) : null;


$api_url = $existing_id
    ? get_rest_url(null, "wc/v3/products/{$existing_id}")
    : get_rest_url(null, 'wc/v3/products');

$method = $existing_id ? 'PUT' : 'POST';

$res = wp_remote_request($api_url, [
    'method'  => $method,
    'headers' => [
        'Authorization' => $auth_header,
        'Content-Type'  => 'application/json',
    ],
    'body'    => json_encode($product),
    'timeout' => 20,
]);

$body = wp_remote_retrieve_body($res);
$code = wp_remote_retrieve_response_code($res);

if ($code >= 200 && $code < 300) {
    $success[] = $product;
    $msg = $existing_id
        ? "🔄 Updated product ID {$existing_id} with SKU {$product['sku']}"
        : "✅ Created new product with SKU {$product['sku']}";
    error_log($msg);
} else {
    $failed[] = ['title' => $product['title'] ?? '(No title)', 'href' => $product['url'] ?? ''];
    error_log("❌ Failed to import simple product. HTTP {$code}: {$body}");
}

                    }

                    $success[] = $product;
                } else {
                    $failed[] = ['title' => $product['title'], 'href' => $product['url']];
                    error_log("❌ Failed to create variable product. HTTP {$code}: {$body}");
                }
            } else {
                $res = wp_remote_post(get_rest_url(null, 'wc/v3/products'), [
                    'method'  => 'POST',
                    'headers' => [
                        'Authorization' => $auth_header,
                        'Content-Type'  => 'application/json',
                    ],
                    'body'    => json_encode($product),
                    'timeout' => 20,
                ]);

                $body = wp_remote_retrieve_body($res);
                $code = wp_remote_retrieve_response_code($res);

                if ($code >= 200 && $code < 300) {
                    $success[] = $product;
                } else {
                    $failed[] = ['title' => $product['title'] ?? '(No title)', 'href' => $product['url'] ?? ''];
                    error_log("❌ Failed to import simple product. HTTP {$code}: {$body}");
                }
            }
        }

        wp_send_json_success([
            'message' => count($success) . ' products imported.',
            'failed'  => $failed
        ]);
    } catch (Throwable $e) {
        error_log('❌ FATAL IMPORT ERROR: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
        wp_send_json_error(['message' => 'Server error: ' . $e->getMessage()]);
    }
});


add_action('admin_footer', function () {
    if (!is_admin()) return;

    $engines = [];
    $dir = WP_CONTENT_DIR . '/uploads/supplier-engines/';
    if (file_exists($dir)) {
        foreach (glob($dir . '*.js') as $file) {
            $slug = basename($file, '.js');
            $engines[] = [
                'slug' => $slug,
                'name' => ucwords(str_replace('-', ' ', $slug)),
            ];
        }
    }

    if (empty($engines)) {
        echo "<script>console.warn('⚠️ No supplier engines found in /uploads/supplier-engines/');</script>";
    }

    $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false]);
    $category_options = array_map(function ($cat) {
        return ['id' => $cat->term_id, 'name' => $cat->name];
    }, is_wp_error($categories) ? [] : $categories);

    $pss_data = [
        'ajaxUrl'         => admin_url('admin-ajax.php'),
        'engineBaseUrl' => plugin_dir_url(__FILE__) . 'assets/engines/',
        'pluginUrl'       => plugin_dir_url(__FILE__),
        'security'        => wp_create_nonce('pss_scraper_nonce'),
        'suppliers'       => $engines,
        'categories'      => $category_options,
        'savedCategories' => get_option('pss_saved_scraper_categories', []),
        'categoryMap' => get_option('pss_category_map', []),

    ];

    echo '<script>window.pssScraperData = ' . json_encode($pss_data) . ';</script>';
    echo '<script type="module" src="' . plugin_dir_url(__FILE__) . 'assets/js/browser-importer.js?v=' . time() . '"></script>';
}, 99);

add_action('wp_ajax_pss_proxy_scrape', function () {
    $nonce = $_POST['security'] ?? $_GET['security'] ?? '';
    if (!wp_verify_nonce($nonce, 'pss_scraper_nonce')) {
        wp_send_json_error('Invalid security nonce');
    }

    $url = esc_url_raw($_POST['url'] ?? $_GET['url'] ?? '');
    if (!$url) wp_send_json_error('Missing URL');

    $parsed = wp_parse_url($url);
    $host = $parsed['host'] ?? '';

    if (strpos($host, 'aquafax.co.uk') !== false) {
        wp_send_json_error(['error' => 'Aquafax requires iframe scraping.']);
    }

    $headers = [];
    if (strpos($host, 'lewmar.com') !== false) {
    $headers = [
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/119 Safari/537.36',
        'Accept' => 'application/json,text/html;q=0.9,*/*;q=0.8',
    ];
}

$response = wp_remote_get($url, [
    'timeout' => 20,
    'headers' => $headers,
]);


    echo wp_remote_retrieve_body($response);
    wp_die();
});

add_action('wp_ajax_pss_get_enricher', function () {
    if (!current_user_can('manage_woocommerce')) {
        status_header(403);
        exit;
    }

    $slug = sanitize_file_name($_GET['engine'] ?? '');
    if (!$slug) {
        status_header(400);
        echo '// Missing engine slug';
        exit;
    }

    $file = WP_CONTENT_DIR . "/uploads/supplier-engines/{$slug}.js";
    if (!file_exists($file)) {
        status_header(404);
        echo "// File not found: {$slug}.js";
        exit;
    }

    header('Content-Type: application/javascript; charset=utf-8');
    readfile($file);
    exit;
});



add_action('admin_init', function () {
    register_setting('pss_settings_group', 'pss_openai_api_key', [
        'sanitize_callback' => 'sanitize_text_field'
    ]);

    add_settings_section(
        'pss_settings_section',
        'AI Integration',
        '__return_null',
        'pss-settings'
    );

    add_settings_field(
        'pss_openai_api_key',
        'OpenAI API Key',
        function () {
            $key = esc_attr(get_option('pss_openai_api_key'));
            echo "<input type='text' name='pss_openai_api_key' value='$key' class='regular-text' />";
            echo "<p class='description'>Used for AI-powered product description generation (GPT-4).</p>";
        },
        'pss-settings',
        'pss_settings_section'
    );
});

add_action('admin_init', function() {
    register_setting('pss_settings_group', 'pss_debug_mode', ['sanitize_callback' => 'sanitize_text_field']);

    add_settings_section(
        'pss_debug_section',
        'Debug & Diagnostics',
        '__return_null',
        'pss-settings'
    );

    add_settings_field(
        'pss_debug_mode',
        'Enable Debug Logging',
        function () {
            $val = get_option('pss_debug_mode', 'no');
            echo '<select name="pss_debug_mode">
                    <option value="no"' . selected($val, 'no', false) . '>No</option>
                    <option value="yes"' . selected($val, 'yes', false) . '>Yes</option>
                  </select>';
            echo '<p class="description">Logs WooCommerce import payloads and REST responses to PHP error log.</p>';
        },
        'pss-settings',
        'pss_debug_section'
    );
});



function pss_render_settings_page() {
    echo '<div class="wrap"><h1>Supplier Scraper Settings</h1>';
    echo '<form method="post" action="options.php">';
    settings_fields('pss_settings_group');
    do_settings_sections('pss-settings');
    submit_button();
    echo '</form></div>';
}

  

